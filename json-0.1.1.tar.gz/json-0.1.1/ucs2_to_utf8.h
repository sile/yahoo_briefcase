#ifndef UCS2_TO_UTF8_H

template<typename T>
inline void ucs2_to_utf8(char fst, char snd, T &to) {
  if(static_cast<unsigned char>(fst)>=0x08) {
    to += 0xE0 | (0xF0&fst)>>4;
    to += 0x80 | (0x0F&fst)<<2 | (0xC0&snd)>>6;
    to += 0x80 | 0x3F&snd;
  } else if(fst!=0 || static_cast<unsigned char>(snd)>=0x80) {
    to += 0xC0 | (fst&0x7)<<2 | (snd&0xC0)>>6;
    to += 0x80 | 0x3F&snd;
  } else {
    to += snd;
  }
}

template<typename T>
inline void surrogate_ucs2_to_utf8(char fst, char snd, char thd, char fth, T &to) {
  to += 0xF0 | 0x03&fst;
  to += 0x80 | ((0xFC&snd)>>2)+0x10;
  to += 0x80 | (0x03&snd)<<4 | (0x03&thd)<<2 | (0xC0&fth)>>6;
  to += 0x80 | 0x3F&fth;
}

inline bool is_surrogate(char ch) {
  unsigned uc = static_cast<unsigned char>(ch);
  return uc >=0xD8 && uc <= 0xDF;
}

#endif
