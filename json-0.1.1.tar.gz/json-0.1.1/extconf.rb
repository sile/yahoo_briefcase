require 'mkmf'
$libs += ' -lstdc++'
create_makefile 'json'
