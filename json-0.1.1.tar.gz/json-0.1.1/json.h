#ifndef JSON_H

#include "json_allocator.h"
#include "ucs2_to_utf8.h"
#include "ruby.h"

#define assert(expr,msg) if(!(expr)){rb_raise(rb_eRuntimeError,msg);}
#define assert2(expr,msg,arg) if(!(expr)){rb_raise(rb_eRuntimeError,msg,arg);}

namespace json{
  // json用のstreamクラス
  class stream {
  public:
    stream(const char *beg, const char* end) 
      : cur_(beg), end_(end) {}

    char read()       { assert(!eof(),"end of file reached"); return *cur_++; }
    void unread()     { --cur_; }
    char prev() const { return cur_[-1]; }
    bool eof()  const { return cur_ >= end_; }
    const char* ptr() const { return cur_; }
    
    char* range(const char *beg, const char *end, allocator& alloc) {
      unsigned size=end-beg;
      char* buf=alloc.allocate(size+1);
      strncpy(buf,beg,size);
      buf[size]='\0';
      return buf;
    }

    char read_skip_ws(){
      for(;;++cur_) {
        assert(!eof(),"end of file reached");
        switch(*cur_){
        case ' ': case '\t': case '\r': case '\n':
          break;
        default:
          return *cur_++;
        }
      }
    }
    
    bool token_end() const { 
      if(eof())
        return true;
      
      switch(*cur_) {
      case ' ': case '\t': case '\r': case '\n': 
      case '}': case ']':  case ',':
        return true;
      }
      return false;
    }
  private:
    const char *cur_;
    const char *end_;
  };

  // jsonパーサクラス
  class parser{
  public:
    parser() :str_buf(alloc) {}

    // JSONの文字列パース用のクラス
    class tmp_string{
    public:
      tmp_string(allocator& alloc_) 
        :alloc(alloc_) {
	clear();
      }
      
      void clear() {
        size=0;
        buf = alloc.allocate(0);
      }
      
      void append(const char* beg, const char* end) {
        unsigned n = end-beg;
        check_and_resize(n);
        strncpy(buf+size,beg,n);
        size += n;
      }
      
      void operator+=(char ch) {
        check_and_resize(1);
        buf[size++]=ch;
      }

      const char* beg() const { return buf; }
      unsigned length() const { return size; } 
    private:
      void check_and_resize(unsigned num) {
        if(alloc.out_of_range(buf+size+num)){
          char *tmp = alloc.allocate(size+num);
          strncpy(tmp,buf,size);
          buf = tmp;
        }
      }
      
      char *buf;
      unsigned  size;
      allocator &alloc;
    };

    /******************/
    /* parse系の関数群 */
    VALUE parse(const char *beg, const char *end) {
      stream in(beg,end);
      return parse_value(in);
    }
    
  private:
    VALUE parse_number(stream &in) {
      const char* beg=in.ptr()-1;
      for(char c=in.prev();; c=in.read()) {
        switch(c){
        case '0': case '1': case '2': case '3': case '4':
        case '5': case '6': case '7': case '8': case '9':
        case '+': case '-': case '.': case 'e': case 'E':
	  if(in.eof())
	    goto end;
          break;
	  
        default:
	  in.unread();
          goto end;
        }
      }
    end:
      
      unsigned size = in.ptr()-beg;
      char* buf = alloc.allocate(size+1);
      strncpy(buf,beg,size);
      buf[size]='\0';

      char* endp;
      double d = strtod(buf, &endp);
      assert2(endp==buf+size,"unexpected token at '%s'",buf);
      return rb_float_new(d);
    }

    VALUE parse_null(stream &in) {
      const char* beg=in.ptr()-1;
      if(in.read()=='u' && in.read()=='l' &&
         in.read()=='l' && in.token_end()) {
        return Qnil;
      }
      assert2(false,"unexpected token at '%s'",in.range(beg,in.ptr(),alloc));
    }
    
    VALUE parse_bool(stream &in, bool maybe_true) {
      const char* beg=in.ptr()-1;
      if(maybe_true) {
        if(in.read()=='r' && in.read()=='u' &&
           in.read()=='e' && in.token_end()) {
          return Qtrue;
        }
      } else {
        if(in.read()=='a' && in.read()=='l' &&
           in.read()=='s' && in.read()=='e' &&
           in.token_end()) {
          return Qfalse;
        }
      }
      assert2(false,"unexpected token at '%s'",in.range(beg,in.ptr(),alloc));
    }

    // 文字を16進数を解釈して、対応する数値を返す
    inline char char_to_hex(stream &in) {
      switch(in.read()) {
#define MAP(c,n) case c: return n;
#define MAP2(c1,c2,n) case c1: case c2: return n;
        MAP('0',0); MAP('1',1); MAP('2',2); MAP('3',3); MAP('4',4);
        MAP('5',5); MAP('6',6); MAP('7',7); MAP('8',8); MAP('9',9);
        MAP2('a','A',10); MAP2('b','B',11); MAP2('c','C',12); 
        MAP2('d','D',13); MAP2('e','E',14); MAP2('f','F',15);
#undef MAP
#undef MAP2
      default:
	assert2(false,"'%c' is not hex character",in.prev());
      }
    }

    // 16進数表記の文字を二つ読み込み、数値(8bit)に変換する
    inline char read_hex(stream &in) {
      return char_to_hex(in)<<4|char_to_hex(in);    
    }

    // "\uXXXX"形式の文字列を読み込む(UTF-8に変換する)
    void parse_escaped_utf16_char(stream &in, tmp_string& s){
      char fst = read_hex(in);
      char snd = read_hex(in);
      
      if(is_surrogate(fst)) {
        assert2(in.read()=='\\' && in.read()=='u', "unexpected token at '%s'", 
		in.range(in.ptr()-8,in.ptr(),alloc));
        surrogate_ucs2_to_utf8(fst,snd,read_hex(in),read_hex(in),s);
      } else {
        ucs2_to_utf8(fst,snd,s);
      }
    }

    VALUE parse_string(stream &in) {
      str_buf.clear();
      const char* beg=in.ptr();
      for(char c=in.read();; c=in.read()) {
        switch(c) {
        case '\\':
          str_buf.append(beg,in.ptr()-1);
          switch(in.read()) {
          case 'b': str_buf += '\b'; break; case 'f': str_buf += '\f'; break;
          case 't': str_buf += '\t'; break; case 'r': str_buf += '\r'; break;
          case 'n': str_buf += '\n'; break;
          case 'u': parse_escaped_utf16_char(in, str_buf); break;
          default:  str_buf += in.prev(); 
          }
          beg=in.ptr();
          break;
        case '"':
          str_buf.append(beg,in.ptr()-1);
          return rb_str_new(str_buf.beg(), str_buf.length());
        }
      }
    }
    
    VALUE parse_array(stream &in) {
      VALUE as=rb_ary_new();
      const char* beg = in.ptr()-1;
        
      if(in.read_skip_ws()!=']') {
        in.unread();
        do{
          rb_ary_push(as,parse_value(in));
        }while(in.read_skip_ws()==',');
	assert2(in.prev()==']',"unexpected token at '%s'",in.range(beg,in.ptr(),alloc));
      }
      return as;
    }

    VALUE parse_object(stream &in) {
      VALUE obj = rb_hash_new();
      const char* beg = in.ptr()-1;
      
      if(in.read_skip_ws()!='}') {
        in.unread();
        do{
          assert2(in.read_skip_ws()=='"',"unexpected token at '%s'",in.range(beg,in.ptr(),alloc));
          VALUE key = parse_string(in);
          assert2(in.read_skip_ws()==':',"unexpected token at '%s'",in.range(beg,in.ptr(),alloc));
	  rb_hash_aset(obj, key, parse_value(in));
        }while(in.read_skip_ws()==',');
	assert2(in.prev()=='}',"unexpected token at '%s'",in.range(beg,in.ptr(),alloc));
      }
      return obj;
    }

    VALUE parse_value(stream &in) {
      switch(in.read_skip_ws()) {
      case '{': return parse_object(in); 
      case '[': return parse_array(in);
      case '"': return parse_string(in);
      case 't': return parse_bool(in,true);
      case 'f': return parse_bool(in,false);
      case 'n': return parse_null(in);
      default:  return parse_number(in);
      }
    }

  private:
    allocator  alloc;
    tmp_string str_buf;
  };
}
#endif
