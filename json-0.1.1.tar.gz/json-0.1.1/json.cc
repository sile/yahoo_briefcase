#include "json.h"
#include <ruby.h>

extern "C"{
  VALUE parser_new(VALUE klass);
  VALUE parser_delete(json::parser *ptr);
  VALUE parser_parse(VALUE self, VALUE json_string);

  void Init_json(void) {
    VALUE mJson = rb_define_module("Json");

    VALUE cJson = rb_define_class_under(mJson,"Parser",rb_cObject);
    rb_define_singleton_method(cJson,"new",(VALUE (*)(...))parser_new,0);
    rb_define_method(cJson, "parse", (VALUE (*)(...))parser_parse, 1);
  }
  
  VALUE parser_new(VALUE klass){
    json::parser* ptr;
    VALUE obj = Data_Make_Struct(klass,json::parser,NULL,parser_delete,ptr);
    new ((void*)ptr) json::parser;
    return obj;
  }
  
  VALUE parser_delete(json::parser *ptr){
    ptr->~parser();
    ruby_xfree(ptr);
  }

  VALUE parser_parse(VALUE self, VALUE json_string) {
    json::parser* ptr;
    Data_Get_Struct(self,json::parser,ptr);

    const char* beg=RSTRING(json_string)->ptr;
    return ptr->parse(beg,beg+RSTRING(json_string)->len);
  }
}
