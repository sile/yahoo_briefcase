#ifndef JSON_ALLOCATOR_H
#include <memory>

namespace json{
  class allocator {
  public:
    allocator(unsigned init_size=0x100) 
      : size_(init_size), buffer_(new char[init_size]) {}

    ~allocator() {
      delete [] buffer_;
    }
    
    char* allocate(unsigned num){
      if(num >= size_) {
	size_ *= 2;
        delete [] buffer_;
	buffer_ = new char[size_];
        
        return allocate(num);
      }
      
      return new (buffer_) char[num];
    }

    bool out_of_range(char* ptr) {
      return buffer_+size_ <= ptr;
    }
  private:
    char*    buffer_;
    unsigned size_;
  };
}

#endif
