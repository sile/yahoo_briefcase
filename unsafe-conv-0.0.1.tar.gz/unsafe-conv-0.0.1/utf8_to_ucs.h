unsigned utf8_to_ucs(const unsigned char*& s) {
#define BYTE(pos,mask,shift) ((s[pos]&mask)<<shift)
  if     (!(*s&0x80)) return *s++;
  else if(!(*s&0x40)) return s++,  0;
  else if(!(*s&0x20)) return s+=2, BYTE(-2,0x1F,6)|BYTE(-1,0x3F,0);
  else if(!(*s&0x10)) return s+=3, BYTE(-3,0xF,12)|BYTE(-2,0x3F,6)| BYTE(-1,0x3F,0); 
  else if(!(*s&0x08)) return s+=4, BYTE(-4,0xF,18)|BYTE(-3,0x3F,12)|BYTE(-2,0x3F,6)|BYTE(-1,0x3F,0);
  for(s++; *s&0x80; s++); 
  return 0;
#undef BYTE
}
