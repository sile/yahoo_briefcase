#include "utf8_to_ucs.h"
#include "sjis_to_ucs.h"
#include "eucjp_to_ucs.h"

#define XXX_octets_to_sbcl_string(encoding) \
  unsigned encoding ## _octets_to_sbcl_string(const unsigned char* src, unsigned char *dist) {\
    const unsigned size = *reinterpret_cast<const unsigned*>(src-4)>>2; \
    const unsigned char* end = src+size; \
    unsigned *cur = reinterpret_cast<unsigned *>(dist); \
    for(; src < end; cur++) \
      *cur = encoding ## _to_ucs(src); \
    return cur-reinterpret_cast<unsigned *>(dist); \
  }

extern "C" {
  XXX_octets_to_sbcl_string(utf8);
  XXX_octets_to_sbcl_string(sjis);
  XXX_octets_to_sbcl_string(eucjp);
}

// Auto-detect character encoding
#include <algorithm>

typedef unsigned (*DECODE_FN) (const unsigned char*&);
struct Decoder {
  Decoder(DECODE_FN fn) : fn(fn), failed_cnt(0) {}

  bool operator<(const Decoder& d) const 
  { return failed_cnt < d.failed_cnt; }

  DECODE_FN fn;
  unsigned failed_cnt;
};

bool isascii(unsigned char c) { return c < 0x80; }

DECODE_FN detect(const unsigned char* octets, const unsigned char* end) {
  Decoder dcs[] = {Decoder(utf8_to_ucs),Decoder(sjis_to_ucs),Decoder(eucjp_to_ucs)};
  
  // Find first position of non ascii character
  for(; octets < end && isascii(*octets); octets++);
  if(octets == end)
    return dcs[0].fn;
  
  // Test all decode functions and count each failure
  for(int i=0; i<3; i++) {
    const unsigned char* tmp_beg=octets;
    const unsigned char* tmp_end=std::min(octets+100,end);
    while(tmp_beg<tmp_end)
      if(dcs[i].fn(tmp_beg)==0)
	dcs[i].failed_cnt++; 
  }

  std::sort(dcs,dcs+3);
  return dcs[0].fn;
}

extern "C" {
  unsigned  octets_to_sbcl_string_auto(const unsigned char* src, unsigned char *dist) {
    const unsigned size = *reinterpret_cast<const unsigned*>(src-4)>>2;
    const unsigned char* end = src+size;
    DECODE_FN decode_to_ucs = detect(src,end);
    
    unsigned *cur = reinterpret_cast<unsigned *>(dist);
    for(; src < end; cur++)
      *cur = decode_to_ucs(src);
    return cur-reinterpret_cast<unsigned *>(dist);
  }
}
