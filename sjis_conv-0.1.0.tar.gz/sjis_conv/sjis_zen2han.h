#define case_set(from_code,to_code,ptr) case from_code: *ptr=to_code; break;
#define case_set2(from_code,to_code1,to_code2,ptr) case from_code: ptr[0]=to_code1; ptr[1]=to_code2; ptr++; break;
void sjis_zen2han(const char* restrict f, char* restrict t) {
  for(; *f != '\0'; f++,t++) {
    if(*f==-125) {
      f++;
      switch(*f) {
	case_set(64,-89,t); // ァ
	case_set(65,-79,t); // ア
	case_set(66,-88,t); // ィ
	case_set(67,-78,t); // イ
	case_set(68,-87,t); // ゥ
	case_set(69,-77,t); // ウ
	case_set(70,-86,t); // ェ
	case_set(71,-76,t); // エ
	case_set(72,-85,t); // ォ
	case_set(73,-75,t); // オ
	case_set(74,-74,t); // カ
	case_set2(75,-74,-34,t); // ガ
	case_set(76,-73,t); // キ
	case_set2(77,-73,-34,t); // ギ
	case_set(78,-72,t); // ク
	case_set2(79,-72,-34,t); // グ
	case_set(80,-71,t); // ケ
	case_set2(81,-71,-34,t); // ゲ
	case_set(82,-70,t); // コ
	case_set2(83,-70,-34,t); // ゴ
	case_set(84,-69,t); // サ
	case_set2(85,-69,-34,t); // ザ
	case_set(86,-68,t); // シ
	case_set2(87,-68,-34,t); // ジ
	case_set(88,-67,t); // ス
	case_set2(89,-67,-34,t); // ズ
	case_set(90,-66,t); // セ
	case_set2(91,-66,-34,t); // ゼ
	case_set(92,-65,t); // ソ
	case_set2(93,-65,-34,t); // ゾ
	case_set(94,-64,t); // タ
	case_set2(95,-64,-34,t); // ダ
	case_set(96,-63,t); // チ
	case_set2(97,-63,-34,t); // ヂ
	case_set(98,-81,t); // ッ
	case_set(99,-62,t); // ツ
	case_set2(100,-62,-34,t); // ヅ
	case_set(101,-61,t); // テ
	case_set2(102,-61,-34,t); // デ
	case_set(103,-60,t); // ト
	case_set2(104,-60,-34,t); // ド
	case_set(105,-59,t); // ナ
	case_set(106,-58,t); // ニ
	case_set(107,-57,t); // ヌ
	case_set(108,-56,t); // ネ
	case_set(109,-55,t); // ノ
	case_set(110,-54,t); // ハ
	case_set2(111,-54,-34,t); // バ
	case_set2(112,-54,-33,t); // パ      
	case_set(113,-53,t); // ヒ
	case_set2(114,-53,-34,t); // ビ
	case_set2(115,-53,-33,t); // ピ      
	case_set(116,-52,t); // フ
	case_set2(117,-52,-34,t); // ブ
	case_set2(118,-52,-33,t); // プ      
	case_set(119,-51,t); // ヘ
	case_set2(120,-51,-34,t); // ベ
	case_set2(121,-51,-33,t); // ペ      
	case_set(122,-50,t); // ホ
	case_set2(123,-50,-34,t); // ボ
	case_set2(124,-50,-33,t); // ポ      
	case_set(125,-49,t); // マ
	case_set(126,-48,t); // ミ
	case_set(-128,-47,t); // ム
	case_set(-127,-46,t); // メ
	case_set(-126,-45,t); // モ
	case_set(-125,-84,t); // ャ
	case_set(-124,-44,t); // ヤ
	case_set(-123,-83,t); // ュ
	case_set(-122,-43,t); // ユ
	case_set(-121,-82,t); // ョ
	case_set(-120,-42,t); // ヨ
	case_set(-119,-41,t); // ラ
	case_set(-118,-40,t); // リ
	case_set(-117,-39,t); // ル
	case_set(-116,-38,t); // レ
	case_set(-115,-37,t); // ロ
	case_set(-114,-36,t); // ヮ
	case_set(-113,-36,t); // ワ
	case_set(-110,-90,t); // ヲ
	case_set(-109,-35,t); // ン
	case_set2(-108,-77,-34,t); // ヴ
      case 0:
	f--;
	*t = *f;
	break;
      default:
	t[0]=f[-1];
	t[1]=f[0];
	t++;
      }
    } else if(*f==-126) {
      f++;
      switch(*f) {
	case_set(79,48,t); // ０
	case_set(80,49,t); // １
	case_set(81,50,t); // ２
	case_set(82,51,t); // ３
	case_set(83,52,t); // ４
	case_set(84,53,t); // ５
	case_set(85,54,t); // ６
	case_set(86,55,t); // ７
	case_set(87,56,t); // ８
	case_set(88,57,t); // ９
 	case_set(96,65,t); // Ａ
	case_set(97,66,t); // Ｂ
	case_set(98,67,t); // Ｃ
	case_set(99,68,t); // Ｄ
	case_set(100,69,t); // Ｅ
	case_set(101,70,t); // Ｆ
	case_set(102,71,t); // Ｇ
	case_set(103,72,t); // Ｈ
	case_set(104,73,t); // Ｉ
	case_set(105,74,t); // Ｊ
	case_set(106,75,t); // Ｋ
	case_set(107,76,t); // Ｌ
	case_set(108,77,t); // Ｍ
	case_set(109,78,t); // Ｎ
	case_set(110,79,t); // Ｏ
	case_set(111,80,t); // Ｐ
	case_set(112,81,t); // Ｑ
	case_set(113,82,t); // Ｒ
	case_set(114,83,t); // Ｓ
	case_set(115,84,t); // Ｔ
	case_set(116,85,t); // Ｕ
	case_set(117,86,t); // Ｖ
	case_set(118,87,t); // Ｗ
	case_set(119,88,t); // Ｘ
	case_set(120,89,t); // Ｙ
	case_set(121,90,t); // Ｚ
 	case_set(-127,97,t); // ａ
	case_set(-126,98,t); // ｂ
	case_set(-125,99,t); // ｃ
	case_set(-124,100,t); // ｄ
	case_set(-123,101,t); // ｅ
	case_set(-122,102,t); // ｆ
	case_set(-121,103,t); // ｇ
	case_set(-120,104,t); // ｈ
	case_set(-119,105,t); // ｉ
	case_set(-118,106,t); // ｊ
	case_set(-117,107,t); // ｋ
	case_set(-116,108,t); // ｌ
	case_set(-115,109,t); // ｍ
	case_set(-114,110,t); // ｎ
	case_set(-113,111,t); // ｏ
	case_set(-112,112,t); // ｐ
	case_set(-111,113,t); // ｑ
	case_set(-110,114,t); // ｒ
	case_set(-109,115,t); // ｓ
	case_set(-108,116,t); // ｔ
	case_set(-107,117,t); // ｕ
	case_set(-106,118,t); // ｖ
	case_set(-105,119,t); // ｗ
	case_set(-104,120,t); // ｘ
	case_set(-103,121,t); // ｙ
	case_set(-102,122,t); // ｚ
      case 0:
	f--;
	*t = *f;
	break;
      default:
	t[0]=f[-1];
	t[1]=f[0];
	t++;	
      }
    } else if(*f==-127) {
      f++;
      switch(*f) {
	case_set(64,32,t);  // '　'
	case_set(65,-92,t); // 、
	case_set(66,-95,t); // 。
	case_set(68,46,t);  // ．
	case_set(69,-91,t); // ・
	case_set(70,58,t);  // ：
	case_set(71,59,t);  // ；
	case_set(72,63,t);  // ？
	case_set(73,33,t);  // ！
	case_set(79,94,t);  // ＾
	case_set(81,95,t);  // ＿
	case_set(94,47,t);  // ／
	// case_set(95,92,t);  // ＼
	case_set(96,126,t); // 〜
	case_set(98,124,t); // ｜
	case_set(102,39,t); // ’
	case_set(103,34,t); // ”
	case_set(104,34,t); // “
	case_set(105,40,t); // （
	case_set(106,41,t); // ）
	case_set(109,91,t); // ［
	case_set(110,93,t); // ］
	case_set(111,123,t);// ｛
	case_set(112,125,t);// ｝
	case_set(117,-94,t);// 「
	case_set(118,-93,t);// 」
	case_set(123,43,t); // ＋
	case_set(-127,61,t);// ＝
	case_set(-125,60,t);// ＜
	case_set(-124,62,t);// ＞
	case_set(-112,36,t);// ＄
	case_set(-109,37,t);// ％
	case_set(-108,35,t);// ＃
	case_set(-107,38,t);// ＆
	case_set(-106,42,t);// ＊
	case_set(-105,64,t);// ＠
	
      case 91:
	*t=45;
	break;
      case 0:
	f--;
	*t = *f;
	break;
      default:
	t[0]=f[-1];
	t[1]=f[0];
	t++;
      }
    } else if (*f < 0 && f[1] != '\0') {
      t[0]=f[0];
      t[1]=f[1];
      f++; 
      t++;
    } else {
      *t = *f;
    }
  }
  *t='\0';
}
#undef case_set
#undef case_set2
