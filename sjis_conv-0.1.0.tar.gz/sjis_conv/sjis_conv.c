#include <ruby.h>

#include "sjis_zen2han.h"

VALUE zen2han(VALUE klass, VALUE text) {
  unsigned len = RSTRING(text)->len;
  char buf[len+1];
  sjis_zen2han(StringValuePtr(text),buf);
  return rb_str_new2(buf);
}

void Init_sjis_conv(void) {
  VALUE cls = rb_define_class("SjisConv",rb_cObject);
  rb_define_singleton_method(cls,"zen2han",zen2han,1);
}

